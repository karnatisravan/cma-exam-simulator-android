package com.cmaexamsimulator.mobile;

import android.os.SystemClock;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class AppLaunchTest {
    @Rule public ActivityScenarioRule<MainActivity> rule = new ActivityScenarioRule<>(MainActivity.class);

    private String evaluate(String script) throws Exception {
        AtomicReference<String> value = new AtomicReference<>("null");
        CountDownLatch latch = new CountDownLatch(1);
        rule.getScenario().onActivity(activity -> activity.getWebViewForTest().evaluateJavascript(script, result -> {
            value.set(result);
            latch.countDown();
        }));
        assertTrue("JavaScript callback timed out", latch.await(10, TimeUnit.SECONDS));
        return value.get();
    }

    private void waitUntilTrue(String script, long timeoutMs) throws Exception {
        long deadline = SystemClock.elapsedRealtime() + timeoutMs;
        String last = "null";
        while (SystemClock.elapsedRealtime() < deadline) {
            last = evaluate(script);
            if ("true".equals(last)) return;
            SystemClock.sleep(350);
        }
        fail("Condition did not become true. Last result: " + last);
    }

    @Test public void loadsOfflineAppWithExactCatalogAndBanks() throws Exception {
        waitUntilTrue("(() => { const banks=globalThis.CMAV2?.getState?.().banks?.length||0; const units=globalThis.CMAPWA?.exactReferenceSections?.().reduce((n,s)=>n+s.units.length,0)||0; return !!document.getElementById('quick-add-questions') && banks>=3 && units===94 && !!globalThis.AndroidFileBridge; })()", 25000);
        assertEquals("\"US CMA Part 2 Exam Simulator\"", evaluate("document.title"));
    }

    @Test public void canAddAQuestionInsideRealWebView() throws Exception {
        waitUntilTrue("(() => !!globalThis.CMAV2?.getState?.().banks?.length && !!document.getElementById('quick-add-questions'))()", 25000);
        String id = "ANDROID-SMOKE-" + UUID.randomUUID().toString().substring(0, 8);
        String setup = "(() => {" +
                "document.getElementById('quick-add-questions').click();" +
                "const set=(id,v)=>{const e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};" +
                "set('easy-manual-section','E');set('easy-manual-unit','E-U03');set('easy-manual-id','" + id + "');" +
                "set('easy-manual-question','Android offline import smoke test?');set('easy-manual-a','Yes');set('easy-manual-b','No');set('easy-manual-c','Maybe');set('easy-manual-d','Unknown');set('easy-manual-answer','A');set('easy-manual-explanation','Created by an Android instrumentation test.');" +
                "document.getElementById('easy-save-manual').click();return true;})()";
        assertEquals("true", evaluate(setup));
        waitUntilTrue("(() => globalThis.CMAV2?.getState?.().questions?.some(q=>q.sourceQuestionId==='" + id + "')===true)()", 15000);
    }
}
