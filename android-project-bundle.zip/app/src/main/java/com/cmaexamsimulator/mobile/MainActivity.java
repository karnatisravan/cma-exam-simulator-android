package com.cmaexamsimulator.mobile;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.SafeBrowsingResponse;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class MainActivity extends Activity {
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html?source=android";
    private static final String WEB_VERSION = "6.0.0-android-1";
    private static final int OPEN_FILE_REQUEST = 4101;
    private static final int SAVE_FILE_REQUEST = 4102;

    private WebView webView;
    private ProgressBar progress;
    private ValueCallback<Uri[]> pendingFileChooser;
    private String pendingSaveContent;
    private String pendingSaveMime;
    private long lastBackPressedAt;
    private File webRoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        progress = findViewById(R.id.progress);
        try {
            webRoot = ensureWebAssets();
            configureWebView();
            if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
                webView.loadUrl(APP_URL);
            }
        } catch (Exception error) {
            progress.setVisibility(View.GONE);
            Toast.makeText(this, "The offline app files could not be prepared: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);

        webView.addJavascriptInterface(new AndroidFileBridge(), "AndroidFileBridge");
        webView.setWebViewClient(new OfflineWebViewClient());
        webView.setWebChromeClient(new AppWebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    public WebView getWebViewForTest() {
        return webView;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        webView.evaluateJavascript("window.dispatchEvent(new Event('cma-app-backgrounding'));", null);
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
        pendingFileChooser = null;
        webView.removeJavascriptInterface("AndroidFileBridge");
        webView.stopLoading();
        webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPressedAt < 1800) {
            super.onBackPressed();
        } else {
            lastBackPressedAt = now;
            Toast.makeText(this, "Press Back again to close the simulator", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OPEN_FILE_REQUEST) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(result);
            pendingFileChooser = null;
            return;
        }
        if (requestCode == SAVE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveContent != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (output == null) throw new IOException("No writable destination was returned.");
                    output.write(pendingSaveContent.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                    Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
                } catch (IOException error) {
                    Toast.makeText(this, "Could not save the file: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveContent = null;
            pendingSaveMime = null;
        }
    }

    private File ensureWebAssets() throws IOException {
        File target = new File(getFilesDir(), "web-v6");
        File marker = new File(target, ".version");
        String current = marker.isFile() ? readSmallText(marker) : "";
        if (WEB_VERSION.equals(current) && new File(target, "index.html").isFile()) return target;
        deleteRecursively(target);
        if (!target.mkdirs() && !target.isDirectory()) throw new IOException("Could not create app storage.");
        String canonicalRoot = target.getCanonicalPath() + File.separator;
        try (InputStream raw = getResources().openRawResource(R.raw.cma_simulator);
             ZipInputStream zip = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry entry;
            byte[] buffer = new byte[16 * 1024];
            while ((entry = zip.getNextEntry()) != null) {
                String name = entry.getName();
                if (name == null || name.isEmpty()) continue;
                File output = new File(target, name);
                String canonicalOutput = output.getCanonicalPath();
                if (!canonicalOutput.startsWith(canonicalRoot)) throw new IOException("Unsafe bundled path rejected.");
                if (entry.isDirectory()) {
                    if (!output.mkdirs() && !output.isDirectory()) throw new IOException("Could not create bundled folder.");
                } else {
                    File parent = output.getParentFile();
                    if (parent != null && !parent.mkdirs() && !parent.isDirectory()) throw new IOException("Could not create bundled folder.");
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
                        int read;
                        while ((read = zip.read(buffer)) != -1) out.write(buffer, 0, read);
                    }
                }
                zip.closeEntry();
            }
        }
        try (OutputStream out = new FileOutputStream(marker)) {
            out.write(WEB_VERSION.getBytes(StandardCharsets.UTF_8));
        }
        if (!new File(target, "index.html").isFile()) throw new IOException("Bundled index.html is missing.");
        return target;
    }

    private static String readSmallText(File file) throws IOException {
        byte[] bytes = new byte[(int) Math.min(file.length(), 128)];
        try (InputStream in = new FileInputStream(file)) {
            int read = in.read(bytes);
            return read <= 0 ? "" : new String(bytes, 0, read, StandardCharsets.UTF_8);
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private final class OfflineWebViewClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return responseFor(request.getUrl().toString());
        }

        @Override
        @SuppressWarnings("deprecation")
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            return responseFor(url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleNavigation(request.getUrl());
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleNavigation(Uri.parse(url));
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            progress.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progress.setVisibility(View.GONE);
        }

        @Override
        public void onSafeBrowsingHit(WebView view, WebResourceRequest request, int threatType, SafeBrowsingResponse callback) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) callback.backToSafety(true);
        }

        private WebResourceResponse responseFor(String url) {
            String assetPath = AssetPathResolver.resolve(url);
            if (assetPath == null) return null;
            try {
                File file = new File(webRoot, assetPath);
                String root = webRoot.getCanonicalPath() + File.separator;
                if (!file.getCanonicalPath().startsWith(root) || !file.isFile()) return notFound();
                String mime = mimeType(assetPath);
                String encoding = isTextMime(mime) ? "UTF-8" : null;
                Map<String, String> headers = new HashMap<>();
                headers.put("Access-Control-Allow-Origin", "https://" + AssetPathResolver.APP_HOST);
                headers.put("Cache-Control", "no-cache");
                headers.put("X-Content-Type-Options", "nosniff");
                return new WebResourceResponse(mime, encoding, 200, "OK", headers, new BufferedInputStream(new FileInputStream(file)));
            } catch (IOException error) {
                return notFound();
            }
        }

        private WebResourceResponse notFound() {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<>(),
                    new java.io.ByteArrayInputStream("Not Found".getBytes(StandardCharsets.UTF_8)));
        }

        private boolean handleNavigation(Uri uri) {
            if (uri == null) return true;
            if ("https".equalsIgnoreCase(uri.getScheme()) && AssetPathResolver.APP_HOST.equalsIgnoreCase(uri.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (ActivityNotFoundException error) {
                Toast.makeText(MainActivity.this, "No app can open this link.", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
    }

    private final class AppWebChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
            pendingFileChooser = callback;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            String[] accept = params == null ? null : params.getAcceptTypes();
            if (accept != null && accept.length > 0 && accept[0] != null && !accept[0].isBlank()) {
                intent.setType(accept[0].contains(",") ? "*/*" : accept[0]);
                intent.putExtra(Intent.EXTRA_MIME_TYPES, accept);
            }
            try {
                startActivityForResult(intent, OPEN_FILE_REQUEST);
                return true;
            } catch (ActivityNotFoundException error) {
                pendingFileChooser = null;
                callback.onReceiveValue(null);
                Toast.makeText(MainActivity.this, "No file picker is available.", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    private final class AndroidFileBridge {
        @JavascriptInterface
        public boolean isAndroidApp() { return true; }

        @JavascriptInterface
        public String getAppVersion() { return WEB_VERSION; }

        @JavascriptInterface
        public void saveTextFile(String filename, String mimeType, String content) {
            final String safeName = sanitizeFilename(filename);
            final String safeMime = (mimeType == null || mimeType.isBlank()) ? "text/plain" : mimeType;
            final String safeContent = content == null ? "" : content;
            runOnUiThread(() -> {
                pendingSaveContent = safeContent;
                pendingSaveMime = safeMime;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(safeMime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try {
                    startActivityForResult(intent, SAVE_FILE_REQUEST);
                } catch (ActivityNotFoundException error) {
                    pendingSaveContent = null;
                    pendingSaveMime = null;
                    Toast.makeText(MainActivity.this, "No save location picker is available.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private static String sanitizeFilename(String filename) {
        String value = filename == null ? "cma-export.txt" : filename.trim();
        value = value.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "-");
        if (value.isEmpty()) value = "cma-export.txt";
        return value.length() > 120 ? value.substring(value.length() - 120) : value;
    }

    private static String mimeType(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".webmanifest")) return "application/manifest+json";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".csv")) return "text/csv";
        if (lower.endsWith(".txt")) return "text/plain";
        String ext = MimeTypeMap.getFileExtensionFromUrl(path);
        String guessed = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return guessed == null ? "application/octet-stream" : guessed;
    }

    private static boolean isTextMime(String mime) {
        return mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") || mime.contains("manifest") || mime.contains("svg");
    }
}
