package com.cmaexamsimulator.mobile;

import java.net.URI;

public final class AssetPathResolver {
    public static final String APP_HOST = "appassets.androidplatform.net";
    private static final String PREFIX = "/assets/";

    private AssetPathResolver() {}

    public static String resolve(String url) {
        try {
            URI uri = URI.create(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || !APP_HOST.equalsIgnoreCase(uri.getHost())) return null;
            String path = uri.getPath();
            if (path == null || path.equals("/") || path.equals("/assets") || path.equals("/assets/")) return "index.html";
            if (!path.startsWith(PREFIX)) return null;
            String relative = path.substring(PREFIX.length());
            if (relative.isEmpty()) return "index.html";
            if (relative.startsWith("/") || relative.contains("../") || relative.contains("\\") || relative.indexOf('\0') >= 0) return null;
            return relative;
        } catch (RuntimeException error) {
            return null;
        }
    }
}
