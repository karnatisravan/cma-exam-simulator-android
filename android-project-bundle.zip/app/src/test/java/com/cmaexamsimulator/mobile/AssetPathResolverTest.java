package com.cmaexamsimulator.mobile;

import org.junit.Test;
import static org.junit.Assert.*;

public class AssetPathResolverTest {
    @Test public void resolvesRootAndAssets() {
        assertEquals("index.html", AssetPathResolver.resolve("https://appassets.androidplatform.net/assets/"));
        assertEquals("styles.css", AssetPathResolver.resolve("https://appassets.androidplatform.net/assets/styles.css?v=1"));
    }
    @Test public void rejectsOtherOriginsAndTraversal() {
        assertNull(AssetPathResolver.resolve("https://example.com/assets/index.html"));
        assertNull(AssetPathResolver.resolve("https://appassets.androidplatform.net/assets/../secret"));
        assertNull(AssetPathResolver.resolve("file:///android_asset/index.html"));
    }
}
