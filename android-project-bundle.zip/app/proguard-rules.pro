# No shrinking is enabled for this offline build.
