# US CMA Exam Simulator — Android APK

This repository builds the offline **US CMA Part 2 Exam Simulator V6.0** as a direct Android APK.

## Included

- Exact HOCK 2024–2025 section and unit catalog (94 units)
- Add one question, paste questions, paste JSON, and select JSON files
- Multiple question banks, tests, notes, analytics, held/remediation queues, and cases
- Fully bundled offline runtime with no localhost server
- Native Android file picker for imports
- Native Android Save dialog for backups and exports
- Persistent WebView IndexedDB storage

## Build result

GitHub Actions runs JVM tests, builds the APK, inspects its package/assets, launches it in an Android emulator, verifies that the exact catalog and default banks load, and adds a real question through the WebView UI. The tested APK is uploaded as the workflow artifact `US-CMA-Exam-Simulator-v6.0-APK`.

## Install

Download `US-CMA-Exam-Simulator-v6.0.apk` from the successful workflow artifact, open it on Android, allow installation from the selected source when Android asks, and tap **Install**. The app appears in the launcher and can be placed on the home screen.
